const data_legend = [
  {
    "name": "pts",
    "color": "red",
  },
  {
    "name": "reb",
    "color": "green",
  },
  {
    "name": "ast",
    "color": "blue",
  }
  ,
  {
    "name": "r:avg",
    "color": "white",
  }
];
let pts_fill_g, pts_x, pts_y;
let reb_fill_g, reb_x, reb_y, reb_histogram;
let ast_fill_g, ast_x, ast_y, ast_histogram;
let age_fill_g, age_x, age_y, age_histogram;
let  gp_fill_g,  gp_x,  gp_y,  gp_histogram;
let dfn_fill_g, dfn_x, dfn_y, dfn_histogram;
let isBrushedBar = false;
let isBrushedScatter = false;
const MARGIN_scatter = { LEFT: 100, RIGHT: 10, TOP: 10, BOTTOM: 130 };
const WIDTH_scatter = 600 - MARGIN_scatter.LEFT - MARGIN_scatter.RIGHT;
const HEIGHT_scatter = 600 - MARGIN_scatter.TOP - MARGIN_scatter.BOTTOM;

const MARGIN_bar = { LEFT: 100, RIGHT: 100, TOP: 10, BOTTOM: 130 }
const WIDTH_bar = 600 - (MARGIN_bar.LEFT + MARGIN_bar.RIGHT)
const HEIGHT_bar = 300 - (MARGIN_bar.TOP + MARGIN_bar.BOTTOM)
const fontSize_bar = 16;

const MARGIN_map = { LEFT: 100, RIGHT: 100, TOP: 10, BOTTOM: 100 };
const FWidth_map = 1200, FHeight_map = 600;
const FLeftTopX_map = 50, FLeftTopY_map = 80;
const projection = d3.geoAlbersUsa();
d3.csv("D3_HW1_data/NBA1516.csv", d3.autoType).then(players => {
  d3.csv("D3_HW1_data/TeamLoc.csv").then(teams => {
    d3.json("D3_HW1_data/us-states.json").then(map => {
      players.forEach(element => {
        if (element.draft_number == "Undrafted")
          element.draft_number = 65;
      });
      // -------------------- scatter ---------------------
      // #region
      const svg_scatter = d3.select("#dot-area").append("svg")
                            .attr("width", WIDTH_scatter + MARGIN_scatter.LEFT + MARGIN_scatter.RIGHT)
                            .attr("height", HEIGHT_scatter + MARGIN_scatter.TOP + MARGIN_scatter.BOTTOM);
      const g_scatter = svg_scatter.append("g")
                                  .attr("transform", `translate(${MARGIN_scatter.LEFT}, ${MARGIN_scatter.TOP})`)                    
      // X ticks
      const x_scatter = d3.scaleLinear()
        .domain([d3.min(players, d => d.umapX), d3.max(players, d => d.umapX)])
        .range([0, WIDTH_scatter]);

      const xAxisCall_scatter = d3.axisBottom(x_scatter).tickFormat(() => "");
      g_scatter.append("g")
        .attr("transform", `translate(0, ${HEIGHT_scatter})`)
        .call(xAxisCall_scatter);

      // Y ticks
      const y_scatter = d3.scaleLinear()
        .domain([d3.min(players, d => d.umapY ), d3.max(players, d => d.umapY)])
        .range([HEIGHT_scatter, 0]);
      

      const yAxisCall_scatter = d3.axisLeft(y_scatter).tickFormat(() => "");
      g_scatter.append("g")
        .call(yAxisCall_scatter);
      const r = d3.scaleLinear()
        .domain([d3.min(players, d => d3.mean([d.ptsNorm, d.rebNorm, d.astNorm])), d3.max(players, d => d3.mean([d.ptsNorm, d.rebNorm, d.astNorm]))])
        .range([3, 6]);
      
      // scatter legend
      let legend = svg_scatter.selectAll(".legend")
                              .data(data_legend)
                              .enter().append("g")
                              .attr("class", "legend")
                              .attr("transform", (d, i) => `translate(${MARGIN_scatter.LEFT + 10}, ${MARGIN_scatter.TOP + i*15})`)
      legend.append("circle")
            .attr("r", 3)
            .style("fill", d=>d.color);
      legend.append("text")
            .attr("x", 10)
            .attr("y", 3)
            .attr("font-size", 12)
            .text(d => d.name);   
      // #endregion
      // brush + tip
      // #region
      let brush = d3.brush()
          .extent([[0, 0], [WIDTH_scatter, HEIGHT_scatter]])
          .on('start', brushed_scatter)
          .on('brush', brushed_scatter)
          .on('end', endBrushed_scatter)
      g_scatter.append('g')
            .attr('class', 'brush')
            .call(brush)
      let selected_players_name = [];
      let tip = d3.tip()
                  .attr('class', 'd3-tip')
                  .html(d=>`Name: ${d.player_name}</br>pts: ${d.pts}</br>reb: ${d.reb}</br>ast: ${d.ast}`)
      let dots = g_scatter.selectAll(".dot")
                  .data(players)
                  .enter().append("circle")
                  .attr('class', 'dot')
                  .attr('stroke', 'black')
                  .attr('stroke-width', '0.5px')
                  .attr("cy", d => y_scatter(d.umapY))
                  .attr("cx", d => x_scatter(d.umapX))
                  .attr('r', d => r(d3.mean([d.ptsNorm, d.rebNorm, d.astNorm])))
                  .attr("fill", function(d, i){
                    const maxNorm = d3.max([d.ptsNorm, d.rebNorm, d.astNorm]);
                    if (d.ptsNorm == maxNorm) return 'red';
                    else if (d.rebNorm == maxNorm) return 'green';
                    else return 'blue';
                  })
                  .call(tip);

      dots.on('mouseover', tip.show)
          .on('mouseout', tip.hide)
      // #endregion
      // ------------------------ map -----------------------------
      // #region 
      const svg_map = d3.select("#map-area").append("svg")
              .attr("width", FWidth_map)
              .attr("height", FHeight_map);    
      let g_map = svg_map.append("g")
              .attr("transform", `translate(${FLeftTopX_map + MARGIN_map.LEFT}, 
                                            ${FLeftTopY_map + MARGIN_map.TOP})`);
      g_map.selectAll("path")
        .data(map.features)
        .enter()
        .append("path")
        .attr("d", d3.geoPath().projection(projection))
        .attr("fill", "#fff")
        .style("stroke", "#000");
      let team_player_num = getTeamPlayersNum(teams, players);
      // console.log(team_player_num)
      let team_dots = svg_map.selectAll("g").data(teams).enter().append("g")
                              .attr("transform", (d, i) => {
                                var po = projection([d.lon, d.lat]);
                                return `translate(${FLeftTopX_map + MARGIN_map.LEFT + po[0]}, ${FLeftTopY_map + MARGIN_map.TOP + po[1]})`;
                              })
                  
      const fontSize_map = 20;
      team_dots.append("circle")
        .attr('r', d => team_player_num[d.team_abbreviation])
        .attr("fill", 'red')
        .attr("opacity", "0.5");
      team_dots.append("text")
        .attr("x", 12)
        .attr("y", 3)
        .attr("font-size", fontSize_map)
        .text(d => d.team_abbreviation); 
      // #endregion 
      // ------------- bar charts --------------------------

      [pts_fill_g, pts_x, pts_y, pts_histogram] = drawBarChart("#pts", players, players, 'pts', 'pts', 40);
      [reb_fill_g, reb_x, reb_y, reb_histogram] = drawBarChart("#reb", players, players, 'reb', 'reb', 30);
      [ast_fill_g, ast_x, ast_y, ast_histogram] = drawBarChart("#ast", players, players, 'ast', 'ast', 20);
      [age_fill_g, age_x, age_y, age_histogram] = drawBarChart("#age", players, players, 'age', 'age', 20);
      [ gp_fill_g,  gp_x,  gp_y,  gp_histogram] = drawBarChart( "#gp", players, players,  'gp',  'gp', 100);
      [dfn_fill_g, dfn_x, dfn_y, dfn_histogram] = drawBarChart("#draft-number", players, players, 'draft_number', 'draft-number', 40);

      // #region
      // console.log(pts_fill_g)
      // ----- pts -----
      let brush_pts = d3.brushX()
                      .extent([[0, 0], [WIDTH_bar, HEIGHT_bar]])
                      .on('start brush', brushed_pts)
                      .on('end', endBrushed_pts)
      let pts_selected = pts_x.domain();
      pts_fill_g.append('g')
                .attr('class', 'brush-bar')
                .call(brush_pts)
      // ----- reb -----
      let brush_reb = d3.brushX()
                      .extent([[0, 0], [WIDTH_bar, HEIGHT_bar]])
                      .on('start brush', brushed_reb)
                      .on('end', endBrushed_reb)
      let reb_selected = reb_x.domain();
      reb_fill_g.append('g')
                .attr('class', 'brush-bar')
                .call(brush_reb)
      // ----- ast -----
      let brush_ast = d3.brushX()
                      .extent([[0, 0], [WIDTH_bar, HEIGHT_bar]])
                      .on('start brush', brushed_ast)
                      .on('end', endBrushed_ast)
      let ast_selected = ast_x.domain();
      ast_fill_g.append('g')
                .attr('class', 'brush-bar')
                .call(brush_ast)
      // ----- age -----
      let brush_age = d3.brushX()
                      .extent([[0, 0], [WIDTH_bar, HEIGHT_bar]])
                      .on('start brush', brushed_age)
                      .on('end', endBrushed_age)
      let age_selected = age_x.domain();
      age_fill_g.append('g')
                .attr('class', 'brush-bar')
                .call(brush_age)
      // ----- gp -----
      let brush_gp = d3.brushX()
                      .extent([[0, 0], [WIDTH_bar, HEIGHT_bar]])
                      .on('start brush', brushed_gp)
                      .on('end', endBrushed_gp)
      let gp_selected = gp_x.domain();
      gp_fill_g.append('g')
                .attr('class', 'brush-bar')
                .call(brush_gp)
      // ----- dfn -----
      let brush_dfn = d3.brushX()
                      .extent([[0, 0], [WIDTH_bar, HEIGHT_bar]])
                      .on('start brush', brushed_dfn)
                      .on('end', endBrushed_dfn)
      let dfn_selected = dfn_x.domain();
      dfn_fill_g.append('g')
                .attr('class', 'brush-bar')
                .call(brush_dfn)
      // #endregion
      // ------------- functions for views -----------------
      
      function brushed_scatter() {
        if (d3.event.selection==null) return;
        var extent = d3.event.selection;//console.log(extent, d3.event.selection);
        dots.classed("selected", function(d) { 
            isSelected = x_scatter(d.umapX) >= extent[0][0] && 
                      x_scatter(d.umapX) <= extent[1][0] && 
                      y_scatter(d.umapY) >= extent[0][1] && 
                      y_scatter(d.umapY) <= extent[1][1];
            if(isSelected) {
              selected_players_name.push(d.player_name);
            }
            return isSelected;
        });
      } // brushed_scatter
      function endBrushed_scatter() {
        if (isBrushedBar) {
          isBrushedBar = false;
          pts_fill_g.select('.brush-bar').call(brush_pts.clear);
          reb_fill_g.select('.brush-bar').call(brush_reb.clear);
          ast_fill_g.select('.brush-bar').call(brush_ast.clear);
          age_fill_g.select('.brush-bar').call(brush_age.clear);
           gp_fill_g.select('.brush-bar').call(brush_gp.clear);
          dfn_fill_g.select('.brush-bar').call(brush_dfn.clear);
        }
        
        if (d3.event.selection==null) {
          clearScatterSelected();
          return;
        }
        isBrushedScatter = true;
        
        let selected_players = [];
        players.forEach(player=>{
          for(let i = 0; i < selected_players_name.length; ++i) {
            if (player.player_name == selected_players_name[i]) { selected_players.push(player); break;}
          }
        })
        transitionSelection(selected_players);
        selected_players_name = [];

      } // endBrushed_scatter

      function clearScatterSelected() {
        // console.log("clearScatterSelected()");
        let team_player_num = getTeamPlayersNum(teams, players);
        // console.log(team_player_num);

        team_dots.selectAll("circle")
                  .transition()
                  .duration(1000)
                  .attr('r', d => team_player_num[d.team_abbreviation]);
                  reRenderingBarChart(pts_fill_g, players, pts_x, pts_y, pts_histogram);
                  reRenderingBarChart(reb_fill_g, players, reb_x, reb_y, reb_histogram);
                  reRenderingBarChart(ast_fill_g, players, ast_x, ast_y, ast_histogram);
                  reRenderingBarChart(age_fill_g, players, age_x, age_y, age_histogram);
                  reRenderingBarChart( gp_fill_g, players,  gp_x,  gp_y,  gp_histogram);
                  reRenderingBarChart(dfn_fill_g, players, dfn_x, dfn_y, dfn_histogram);
      } // clearScatterSelected
      function transitionSelection (selected_players, isBar) {
        let team_player_num = getTeamPlayersNum(teams, selected_players);
        team_dots.selectAll("circle")
                  .transition()
                  .duration(1000)
                  .attr('r', d => team_player_num[d.team_abbreviation]);
        // console.log(pts_fill_g)
        reRenderingBarChart(pts_fill_g, selected_players, pts_x, pts_y, pts_histogram);
        reRenderingBarChart(reb_fill_g, selected_players, reb_x, reb_y, reb_histogram);
        reRenderingBarChart(ast_fill_g, selected_players, ast_x, ast_y, ast_histogram);
        reRenderingBarChart(age_fill_g, selected_players, age_x, age_y, age_histogram);
        reRenderingBarChart( gp_fill_g, selected_players,  gp_x,  gp_y,  gp_histogram);
        reRenderingBarChart(dfn_fill_g, selected_players, dfn_x, dfn_y, dfn_histogram);
        if (isBar) {
          dots.transition()
              .duration(1000)
              .attr('stroke-width', d => {
                let isSelected = false;
                selected_players.forEach(player=>{
                  if (d==player) {
                    isSelected = true;
                  }
                })
                if (isSelected)
                  return '0.5px';
                else
                  return '0';
              })
              .attr("fill-opacity", d => {
                let isSelected = false;
                selected_players.forEach(player=>{
                  if (d==player) {
                    isSelected = true;
                  }
                })
                if (isSelected)
                  return '1';
                else
                  return '0.4';
              })
        }
      } // transitionSelection
      function filter_bar_selected() {
        let selected_players = []
        players.forEach(player=>{
          // filter bar chart selection
          if ((player.pts >= pts_selected[0] && player.pts <= pts_selected[1]) &&
              (player.reb >= reb_selected[0] && player.reb <= reb_selected[1]) &&
              (player.ast >= ast_selected[0] && player.ast <= ast_selected[1]) &&
              (player.age >= age_selected[0] && player.age <= age_selected[1]) &&
              ( player.gp >=  gp_selected[0] &&  player.gp <=  gp_selected[1]) &&
              (player.draft_number >= dfn_selected[0] && player.draft_number <= dfn_selected[1])
             )
            selected_players.push(player);
        })
        return selected_players;
      }
      // ------------- brush for bar charts -------------------
      //#region 
      function brushed_pts() {
        if (d3.event.selection==null) return;
        var extent = d3.event.selection;//console.log(extent, d3.event.selection);
        let reverse_x = d3.scaleLinear()
                      .domain(pts_x.range())
                      .range(pts_x.domain())
        // console.log(reverse_x(extent[0]), reverse_x(extent[1]));
        
        pts_selected = [reverse_x(extent[0]), reverse_x(extent[1])];
      } // brushed_pts
      function endBrushed_pts() {
        if (isBrushedScatter) {
          isBrushedScatter = false;
          d3.select('.brush')
            .call(brush.clear)
        }
        if (d3.event.selection==null) {
          // console.log(pts_x.domain())
          pts_selected = pts_x.domain();
        }
        else {
          isBrushedBar = true;
        }
        let selected_players = filter_bar_selected();
        transitionSelection(selected_players, true);
      } // endBrushed_pts
      function brushed_reb() {
        if (d3.event.selection==null) return;
        var extent = d3.event.selection;//console.log(extent, d3.event.selection);
        let reverse_x = d3.scaleLinear()
                      .domain(reb_x.range())
                      .range(reb_x.domain())
        // console.log(reverse_x(extent[0]), reverse_x(extent[1]));
        
        reb_selected = [reverse_x(extent[0]), reverse_x(extent[1])];
      } // brushed_reb
      function endBrushed_reb() {
        if (isBrushedScatter) {
          isBrushedScatter = false;
          d3.select('.brush')
            .call(brush.clear)
        }
        if (d3.event.selection==null) {
          reb_selected = reb_x.domain();
        } else {
          isBrushedBar = true;
        }
        let selected_players = filter_bar_selected();
        transitionSelection(selected_players, true);

      } // endBrushed_reb
      function brushed_ast() {
        if (d3.event.selection==null) return;
        var extent = d3.event.selection;
        let reverse_x = d3.scaleLinear()
                      .domain(ast_x.range())
                      .range(ast_x.domain())
        ast_selected = [reverse_x(extent[0]), reverse_x(extent[1])];
      } // brushed_ast
      function endBrushed_ast() {
        if (isBrushedScatter) {
          isBrushedScatter = false;
          d3.select('.brush')
            .call(brush.clear)
        }
        if (d3.event.selection==null) ast_selected = ast_x.domain();
        else {
          isBrushedBar = true;
        }
        let selected_players = filter_bar_selected();
        transitionSelection(selected_players, true);
      } // endBrushed_ast
      function brushed_age() {
        if (d3.event.selection==null) return;
        var extent = d3.event.selection;
        let reverse_x = d3.scaleLinear()
                      .domain(age_x.range())
                      .range(age_x.domain())
        age_selected = [reverse_x(extent[0]), reverse_x(extent[1])];
      } // brushed_age
      function endBrushed_age() {
        if (isBrushedScatter) {
          isBrushedScatter = false;
          d3.select('.brush')
            .call(brush.clear)
        }
        if (d3.event.selection==null) age_selected = age_x.domain();
        else {
          isBrushedBar = true;
        }
        let selected_players = filter_bar_selected();
        transitionSelection(selected_players, true);
      } // endBrushed_age
      function brushed_gp() {
        if (d3.event.selection==null) return;
        var extent = d3.event.selection;
        let reverse_x = d3.scaleLinear()
                      .domain(gp_x.range())
                      .range(gp_x.domain())
        gp_selected = [reverse_x(extent[0]), reverse_x(extent[1])];
      } // brushed_gp
      function endBrushed_gp() {
        if (isBrushedScatter) {
          isBrushedScatter = false;
          d3.select('.brush')
            .call(brush.clear)
        }
        if (d3.event.selection==null) gp_selected = gp_x.domain();
        else {
          isBrushedBar = true;
        }
        let selected_players = filter_bar_selected();
        transitionSelection(selected_players, true);
      } // endBrushed_gp
      function brushed_dfn() {
        if (d3.event.selection==null) return;
        var extent = d3.event.selection;
        let reverse_x = d3.scaleLinear()
                      .domain(dfn_x.range())
                      .range(dfn_x.domain())
        dfn_selected = [reverse_x(extent[0]), reverse_x(extent[1])];
      } // brushed_dfn
      function endBrushed_dfn() {
        if (isBrushedScatter) {
          isBrushedScatter = false;
          d3.select('.brush')
            .call(brush.clear)
        }
        if (d3.event.selection==null) dfn_selected = dfn_x.domain();
        else {
          isBrushedBar = true;
        }
        let selected_players = filter_bar_selected();
        transitionSelection(selected_players, true);
      } // endBrushed_gp
      //#endregion
    }) // us-states.json
  }) // TeamLoc.csv
}) // NBA1516.csv



function reRenderingBarChart(selected_g, selected_players, x, y, histogram) {
  const FHeight_bar = 300;
  const MARGIN_bar = { LEFT: 100, RIGHT: 100, TOP: 10, BOTTOM: 130 }
  const HEIGHT_bar = FHeight_bar - (MARGIN_bar.TOP + MARGIN_bar.BOTTOM)

  fill_bins = histogram(selected_players);
  // console.log(fill_bins);
  selected_g.selectAll("rect")
          .data(fill_bins)
          .transition()
          .duration(1000)
          .attr("y", d => (HEIGHT_bar - y(d.length))) 
          // .attr("transform", d => `translate(${pts_x(d.x0)}, 0)`) 
          .attr("height", d => y(d.length))
  // console.log(selected_g)
} // reRenderingBarChart

function getTeamPlayersNum(teams, players) {
  let team_player_num = {};
  teams.forEach(element => {
    team_player_num[element.team_abbreviation] = 0;
  });
  players.forEach(element => {
    team_player_num[element.team_abbreviation] += 1;
  });
  return team_player_num;
} // getTeamPlayersNum
function drawBarChart(selected_div, all_players, selected_players, attribute, title, tick_nums) {
  
  
  let svg = d3.select(selected_div).append("svg")
              .attr("width", WIDTH_bar + MARGIN_bar.LEFT + MARGIN_bar.RIGHT)
              .attr("height", HEIGHT_bar + MARGIN_bar.TOP + MARGIN_bar.BOTTOM)
  let g = svg.append("g")
              .attr("transform", `translate(${MARGIN_bar.LEFT}, ${MARGIN_bar.TOP})`)
  // X ticks
  const x = d3.scaleLinear()
      .domain([d3.min(all_players, d => d[attribute]), d3.max(all_players, d => d[attribute])])
      .range([0, WIDTH_bar])

  g.append("g")
    .attr("transform", `translate(0, ${HEIGHT_bar})`)
    .call(d3.axisBottom(x));

  let histogram = d3.histogram()
                        .value(d => d[attribute])
                        .domain(x.domain())
  
  if (tick_nums != undefined) histogram.thresholds(x.ticks(tick_nums));
  const bins = histogram(all_players);
  // console.log(bins);
  // Y ticks
  const y = d3.scaleLinear()
    .domain([0, d3.max(bins, d => d.length)])
    .range([0, HEIGHT_bar])
    
  g.append("g")
    .call(d3.axisLeft(y))   
  g.selectAll("rect")
    .data(bins)
    .enter().append("rect")
    .attr("x", d => x(d.x0))
    .attr("y", d => (HEIGHT_bar-y(d.length)))
    .attr("width", d => x(d.x1)-x(d.x0))
    .attr("height", d => y(d.length))
      .style("fill",  `rgba(0, 0, 0, 0)`)
      .attr('stroke', 'black')
      .attr('stroke-width', "0.5px")
  svg.append("text")
    .attr("transform", `translate(${MARGIN_bar.LEFT+ 10}, ${MARGIN_bar.TOP})`)
    .attr("font-size", fontSize_bar)
    .text(title) 
  let fill_g = svg.append("g")
    .attr("transform", `translate(${MARGIN_bar.LEFT}, ${MARGIN_bar.TOP})`)
  const fill_bins = histogram(selected_players);
  // console.log(fill_bins)
  // console.log(fill_bins);
  fill_g.selectAll("rect")
    .data(fill_bins)
    .enter()
    .append("rect")
      // .attr('class', `${title}-bin`)
      .attr("x", d => x(d.x0))
      .attr("y", d => (HEIGHT_bar-y(d.length)))
      .attr("width", d => x(d.x1)-x(d.x0))
      .attr("height", d => y(d.length))
      .style("fill", "rgba(105, 179, 162, 16)")
    // console.log(fill_g)
  return [fill_g, x, y, histogram];
} // drawBarChart